/*
 * TCP_protocol.h
 *
 *  Created on: 20 nov 2022
 *      Author: giorg
 */

#ifndef TCP_PROTOCOL_H_
#define TCP_PROTOCOL_H_

#define PROTOPORT 6000
#define BUFFER_SIZE 64
#define QLEN 5

#endif /* TCP_PROTOCOL_H_ */
